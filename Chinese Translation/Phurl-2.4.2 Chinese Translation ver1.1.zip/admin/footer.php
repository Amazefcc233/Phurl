<div id="footer">
<p>&copy; <?php echo date("Y"); ?> <?php echo SITE_TITLE ?> - Powered by <a href="http://code.google.com/p/phurl">Phurl <?php echo PHURL_VERSION ?></a> | 汉化 by fcc </p>
</div>
</div>
</body>
</html>
