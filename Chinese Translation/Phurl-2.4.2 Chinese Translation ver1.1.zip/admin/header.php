<?php
ini_set('display_errors', 0);
?>
<html>
<head>
<title>Phurl管理面板</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="../assets/admin.css" />
<script type="text/javascript" src="../assets/admin.js"></script>
<style type="text/css">
.style2 {
	font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
}
</style>
</head>
<body>
<?php if (is_admin_login()): ?>
<img src="/assets/phurl.png" alt="Phurl" height="52" width="116" />

<span class="style2">管理面板 | <a href="/admin/logout.php">登出</a><hr />
<?php
$updateurl = "http://liveupdate.hencogroup.co.uk/os/phurl/latest.txt";
$fh = fopen($updateurl, 'r');
$version = fread($fh, 3);
fclose($fh);
$current = PHURL_NUMERICVERSION;
if ($version > $current && $version !== $current) {
echo "<center><p style=\"color:green;\">新版本可用! 请在 <a href=\"http://code.google.com/p/phurl/downloads/list\">http://code.google.com/p/phurl/downloads/list</a> 下载（自行翻墙）</p></center><hr/>";
} 
elseif ($version < $current && $version !== $current) {
echo "<center><p style=\"color:blue;\">您当前正在使用最新版本.</p></center><hr/>";
}
?>
<h2>搜索</h2>
<form method="get" action="index.php">
<table id="admin_search">
<tr>
<td><strong>通过Code或自定义后缀搜索:</strong></td>
<td><input type="text" name="search_alias" size="30" value="<?php echo @htmlentities($_GET['search_alias']) ?>" /></td>
</tr>
<tr>
<td><strong>通过URL关键字搜索:</strong></td>
<td><input type="text" name="search_url" size="30" value="<?php echo @htmlentities($_GET['search_url']) ?>" /></td>
</tr>
<tr>
<td>&nbsp;</td>
<td><input type="submit" value="Search" /></td>
</tr>
</table>
</form>
<hr />
<?php endif; ?>