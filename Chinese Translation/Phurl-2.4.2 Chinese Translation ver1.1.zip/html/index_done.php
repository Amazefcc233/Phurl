<?php
if( !defined('PHURL' ) ) {
    header('HTTP/1.0 404 Not Found');
    exit();
}
ini_set('display_errors', 0);
?>
<h2>短网址已创建!</h2>
<p>长地址: <strong><?php echo htmlentities($url) ?></strong> (<?php echo strlen($url) ?> 个字符)</p>
<p>短网址: <strong><a href="<?php echo htmlentities($short_url) ?>" target="_blank"><?php echo htmlentities($short_url) ?></a></strong> (<?php echo strlen($short_url) ?> 个字符)<br />

