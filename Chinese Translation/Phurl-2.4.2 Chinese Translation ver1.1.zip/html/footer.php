<?php
if( !defined('PHURL' ) ) {
    header('HTTP/1.0 404 Not Found');
    exit();
}
ini_set('display_errors', 0);
?>
<h2>浏览器书签</h2>
<div id="bookmarklets">
<p>拖动以下链接到您浏览器的工具栏中。</p>
<p><a href="javascript:(function(){var%20ali=prompt('Enter%20a%20custom%20alias:');if(ali){location.href='<?php echo SITE_URL ?>/index.php?url='%20+%20escape(location.href)%20+%20'&alias='+ali;}})();" title="使用后缀进行缩短">使用自定义后缀进行缩短</a><br />
<a href="javascript:void(location.href='<?php echo SITE_URL ?>/index.php?alias=&url='+escape(location.href))">不使用自定义后缀缩短</a></p>
</div>
</div>
<div id="footer">
<p>&copy; <?php echo date("Y"); ?> <?php echo SITE_TITLE ?> - Powered by <a href="http://code.google.com/p/phurl">Phurl <?php echo PHURL_VERSION ?></a> | 汉化 by fcc </p>
</div>
</div>
</body>
</html>