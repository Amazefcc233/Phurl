<?php
if( !defined('PHURL' ) ) {
    header('HTTP/1.0 404 Not Found');
    exit();
}
ini_set('display_errors', 0);
?>
<h2>创建短网址</h2>
<?php print_errors() ?>
<div id="create_form">
<form method="get" action="index.php">
<p><label for="url">在此处键入原地址 (URL) :</label><br />
<input id="url" type="text" name="url" value="<?php echo htmlentities(@$_GET['url']) ?>" />
<input class="button" type="submit" value="Shorten" /></p>
<p><label for="alias">自定义后缀 (可选):</label><br />
<?php echo SITE_URL ?>/<input id="alias" maxlength="40" type="text" name="alias" value="<?php echo htmlentities(@$_GET['alias']) ?>" /><br />
<em>可包含字母、数字、横杠-和下划线_</em></p>
</form>
</div>
<script type="text/javascript">
//<![CDATA[
if (document.getElementById) {
    document.getElementById('url').focus();
}
//]]>
</script>