<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Phurl安装程序(5/5)</title>
<style type="text/css">
.style2 {
	font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
}
</style>
</head>

<body>

<img src="/assets/phurl.png" alt="Phurl" height="52" width="116" />

<span class="style2">安装<hr />

<?php
error_reporting(0);
$server = $_POST['server'];
$user = $_POST['user'];
$pass = $_POST['pass'];
$db = $_POST['db'];
$siteurl = $_POST['siteurl'];
$sitetitle = $_POST['sitetitle'];
$adminuser = $_POST['adminuser'];
$adminpass = $_POST['adminpass'];
?>


<?php $File = "../config.php"; $Handle = fopen($File, 'w'); $Data = "<?php\n"; fwrite($Handle, $Data); $Data = "define('DB_HOSTNAME', '$server');\n"; fwrite($Handle, $Data); $Data = "define('DB_USERNAME', '$user');\n"; fwrite($Handle, $Data); $Data = "define('DB_PASSWORD', '$pass');\n"; fwrite($Handle, $Data); $Data = "define('DB_NAME', '$db');\n"; fwrite($Handle, $Data); $Data = "define('DB_VERSION', '4');\n"; fwrite($Handle, $Data); $Data = "define('DB_PREFIX', 'phurl_');\n"; fwrite($Handle, $Data); $Data = "define('SITE_URL', '$siteurl');\n"; fwrite($Handle, $Data); $Data = "define('SITE_TITLE', '$sitetitle');\n"; fwrite($Handle, $Data); $Data = "define('ADMIN_USERNAME', '$adminuser');\n"; fwrite($Handle, $Data); $Data = "define('ADMIN_PASSWORD', '$adminpass');\n"; fwrite($Handle, $Data); $Data = "define('URL_PROTOCOLS', 'http|https|ftp|ftps|mailto|news|mms|rtmp|rtmpt|e2dk');\n"; fwrite($Handle, $Data); $Data = "define('PHURL_VERSION', '2.4.2');\n"; fwrite($Handle, $Data); $Data = "define('PHURL_NUMERICVERSION', '242');\n"; fwrite($Handle, $Data); $Data = "error_reporting(E_ALL);\n"; fwrite($Handle, $Data); $Data = "\$_ERROR = array();\n"; fwrite($Handle, $Data); fclose($Handle); ?>

<?php
$config = '../config.php';
if (file_exists($config)) {
echo "<p style=\"color:green;\">成功!我们已设置完成配置文件! 请<b style=\"color:red;\">务必删除install文件夹</b>然后前往<?php echo $siteurl; ?>来开始缩短网址吧!注: 您站点的管理员控制面板在 <?php echo $siteurl; ?>/admin/ 。主页没有登录入口。</p>";
}
else {
echo "<p style=\"color:red;\">非常抱歉，在写入配置文件时发送错误. 请确保您的phurl网址缩短服务文件夹权限已设置为777，然后重试.</p>";
}
?>