<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Phurl安装程序(3/5)</title>
<style type="text/css">
.style2 {
	font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
}
</style>
</head>

<body>

<img src="/assets/phurl.png" alt="Phurl" height="52" width="116" />

<span class="style2">安装<hr />

<?php
require("../functions.php");
error_reporting(0);
define("DB_HOSTNAME", $_POST['server']);
define("DB_USERNAME", $_POST['user']);
define("DB_PASSWORD", $_POST['pass']);
define("DB_NAME",     $_POST['db']);
define("DB_VERSION",  4);

        db_connect();
        mysql_query("CREATE TABLE IF NOT EXISTS `phurl_settings` ( last_number bigint(20) unsigned NOT NULL default '0', KEY last_number (last_number) ) ENGINE = MYISAM") or die(mysql_error());
        mysql_query("INSERT INTO phurl_settings VALUES (1)");
        mysql_query("CREATE TABLE IF NOT EXISTS `phurl_urls` ( id int(10) unsigned NOT NULL auto_increment, url text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, code varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL default '', alias varchar(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL default '', date_added datetime NOT NULL default '0000-00-00 00:00:00', PRIMARY KEY  (id), UNIQUE KEY code (code), KEY alias (alias) ) ENGINE = MYISAM") or die(mysql_error());
	mysql_query("INSERT INTO phurl_urls VALUES (1,'http://phurl.googlecode.com/','a','phurl','2010-07-03 15:40:56')");
        ?>
       
<p style="color:green;">数据库已成功安装! 我们现在需要配置一下相关文件. 我们需要一些关于这个站点更多的数据, 所以点击Next按钮来进行下一步操作吧.</p>
<form action="4.php" class="style2" method="post">
<input name="server" style="width: 150px" type="hidden" value="<?php echo $_POST['server']; ?>" />
<input name="user" style="width: 150px" type="hidden" value="<?php echo $_POST['user']; ?>" />
<input name="pass" style="width: 150px" type="hidden" value="<?php echo $_POST['pass']; ?>" />
<input name="db" style="width: 150px" type="hidden" value="<?php echo $_POST['db']; ?>" />
<input name="Submit1" type="submit" value="Next -&gt;" />
</form>