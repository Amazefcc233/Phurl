<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Phurl安装程序(4/5)</title>
<style type="text/css">
.style2 {
	font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
}
</style>
</head>

<body>

<img src="/assets/phurl.png" alt="Phurl" height="52" width="116" />

<span class="style2">安装<hr />

<p>请在下方输入所有相关信息.</p>

<form action="5.php" class="style2" method="post" style="height: 132px">
	<table style="width: 100%">
		<tr>
			<td>MySQL服务器:</td>
			<td><input name="server" style="width: 150px" type="text" value="<?php echo $_POST['server']; ?>" /></td>
			<td rowspan="4">您已经输入完成, 我们只是想要确认一下.</td>
		</tr>
		<tr>
			<td>MySQL用户名:</td>
			<td>
			<input name="user" style="width: 150px" type="text" value="<?php echo $_POST['user']; ?>" /></td>
		</tr>
		<tr>
			<td style="height: 24px">MySQL密码:</td>
			<td style="height: 24px">
			<input name="pass" style="width: 150px" type="password" value="<?php echo $_POST['pass']; ?>" /></td>
		</tr>
		<tr>
			<td>MySQL数据库Database:</td>
			<td>
			<input name="db" style="width: 150px" type="text" value="<?php echo $_POST['db']; ?>" /></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>站点名:</td>
			<td>
			<input name="sitetitle" style="width: 150px" type="text" /></td>
			<td>将会在标题显示.</td>
		</tr>
		<tr>
			<td>站点URL:</td>
			<td>
			<input name="siteurl" style="width: 150px" type="text" /></td>
			<td>站点的URL. <strong>不要在最后添加斜杠/</strong>.</td>
		</tr>
		<tr>
			<td>管理员用户名:</td>
			<td>
			<input name="adminuser" style="width: 150px" type="text" value="admin" /></td>
			<td>您想用来登陆的用户名.</td>
		</tr>
		<tr>
			<td>管理员密码:</td>
			<td>
			<input name="adminpass" style="width: 150px" type="password" /></td>
			<td>您想用来登录的密码.</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
	</table>
	<p>警告！以上所有内容将会以<strong>明文</strong>形式保存在服务器本地config.php下，<strong>包括MySQL&管理员密码</strong>！请注意通信安全！</p>
	<p>若要加强安全性，您可能需要重命名文件config.php，或将其移动到其它目录中。但您<strong>必须同时修改各页面对config.php的连接路径。这一过程极其繁琐且复杂，并且可能不会奏效。请谨慎操作。</strong></p>
	&nbsp;<input name="Submit1" type="submit" value="Next -&gt;"></form>