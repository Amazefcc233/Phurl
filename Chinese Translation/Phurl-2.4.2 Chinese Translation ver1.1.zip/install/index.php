<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"><html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Phurl安装程序(1/5)</title>
<style type="text/css">
.style2 {
	font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
}
</style>
</head>

<body>

<img src="/assets/phurl.png" alt="Phurl" height="52" width="116" />

<span class="style2">安装</span><hr />
<p class="style2">欢迎使用Phurl!这是一个缩短网址的应用。</p>
<p class="style2">在开始之前，请确保您的目录权限已设置为777，否则安装不能成功。</p>
<p class="style2">运行本应用，您还需要: PHP和MySQL (版本建议:PHP5.6及以下 MySQL5.6及以下 php版本高于5.6将会导致500 Internet server error而无法进行访问/安装！)</p>
<p class="style2">一切都准备就绪？那就开始在下方输入MySQL相关信息吧~</p>
<p class="style2">(下方为原英语介绍，中文并没有按照原来的内容翻译，可选看)</p>
<p class="style2">Welcome to Phurl! This wizard will help you get started with a 
neat little phurl-based URL shortener in a matter of moments.</p>
<p class="style2">Before we begin, you need to make sure that the directory your url shortener lies in is writable by the server (chmodded to 777). If the server cannot write to that directory, the config file will not be written and installation will fail.</p>
<p class="style2">Once the directory is chmodded, the first thing we need to do is install the database 
structure required for phurl to work. You will need to create a database and a 
user that has full permissions over that database. Once done, enter the details 
below:</p>
<form action="2.php" class="style2" method="post" style="height: 132px">
	MySQL服务器:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input name="server" style="width: 150px" type="text" value="localhost" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
	默认localhost，有特殊要求请重新键入.<br />
	MySQL用户名:&nbsp;&nbsp;&nbsp;
	<input name="user" style="width: 150px" type="text" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
	登录MySQL的用户名.<br />
	MySQL密码:&nbsp;&nbsp;&nbsp;
	<input name="pass" style="width: 150px" type="password" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
	登录MySQL的密码.<br />
	MySQL数据库Database:&nbsp;&nbsp;&nbsp;&nbsp;
	<input name="db" style="width: 150px" type="text" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
	您想使用的数据库名.<br />
	<input name="Submit1" type="submit" value="Next -&gt;" /></form>

</body>

</html>