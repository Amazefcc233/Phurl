This is a beta of Phurl version 2 series.

Please navigate to /install to begin setting up phurl.

Please report bugs and send feature ideas at http://code.google.com/p/phurl/issues/list

============
以上都是开发者说的话。
以下都是汉化者fcc说的话。

php版本不得高于5.6，否则500Internet server error，站点无法安装/访问。
此汉化版本中修复了一些bug，比如说: 无法安装数据库...之类的
此汉化版本同时还优化了些使用体验emmm
有些重要事项将在安装程序中一并讲述清楚，请务必仔细阅读。（这包含着一些安全性问题）
在安装完成之后，请务必卸载安装目录，否则站点将无法访问，或出现严重bug。
压缩包同时会放置原始安装包（Phurl2.4.2.tar.gz），若站点出现问题可考虑使用此包解决问题。
感谢您的阅读。请现在打开您的站点，进行安装吧。