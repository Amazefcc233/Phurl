<?php
define('PHURL', true);
ini_set('display_errors', 0);
$prefix[0] = '';
$filename = 'install';
if (is_dir($filename)) {
    die ("若想设置Phurl并且运行, 您需要前往 <a href=\"install\">安装面板</a> 进行安装操作。<br/><br/>如果您已安装Phurl, 请务必删除install文件夹，才能开始运行.");
}
?>
<?php
require_once("config.php");
require_once("functions.php");

db_connect();

if (count($_GET) > 0) {
    $url   = mysql_real_escape_string(trim($_GET['url']));
    $alias = mysql_real_escape_string(trim($_GET['alias']));

    if (!preg_match("/^(".URL_PROTOCOLS.")\:\/\//i", $url)) {
 	$prefix = explode(":", $url);
 	if ($prefix[0] == 'mailto') {
 		$url = $url;
 	} else {
        $url = "http://".$url;
 	}
    }

    $last = $url[strlen($url) - 1];

    if ($last == "/") {
        $url = substr($url, 0, -1);
    }

    $data = @parse_url($url);
		if ($prefix[0] == 'mailto') {
			$data['scheme'] = 'mailto';
			$data['host'] = 'none';
		}
    if (strlen($url) == 0) {
        $_ERROR[] = "请输入一个链接来缩短。";
    }
    else if (empty($data['scheme']) || empty($data['host'])) {
        $_ERROR[] = "请输入一个有效的链接来缩短。";
    }
    else {
        $hostname = get_hostname();
        $domain   = get_domain();

        if (preg_match("/($hostname)/i", $data['host'])) {
            $_ERROR[] = "您所键入的链接不被允许缩短。";
        }
    }

    if (strlen($alias) > 0) {
        if (!preg_match("/^[a-zA-Z0-9_-]+$/", $alias)) {
            $_ERROR[] = "自定义后缀只能包含字母、数字、下划线_和横杠-。";
        }
        else if (code_exists($alias) || alias_exists($alias)) {
            $_ERROR[] = "您所键入的自定义后缀已被占用。请您更换后再试。";
        }
    }

    if (count($_ERROR) == 0) {
        $create = true;

        if (($url_data = url_exists($url))) {
            $create    = false;
            $id        = $url_data[0];
            $code      = $url_data[1];
            $old_alias = $url_data[2];

            if (strlen($alias) > 0) {
                if ($old_alias != $alias) {
                    $create = true;
                }
            }
        }

        if ($create) {
            do {
                $code = generate_code(get_last_number());

                if (!increase_last_number()) {
                    die("系统错误!");
                }

                if (code_exists($code) || alias_exists($code)) {
                    continue;
                }

                break;
            } while (1);

            $id = insert_url($url, $code, $alias);
        }

        if (strlen($alias) > 0) {
            $code = $alias;
        }

        $short_url = SITE_URL."/".$code;

        $_GET['url']   = "";
        $_GET['alias'] = "";

        require_once("html/header.php");
        require_once("html/index_done.php");
        require_once("html/index_form.php");
        require_once("html/footer.php");
        exit();
    }
}

require_once("html/header.php");
require_once("html/index_form.php");
require_once("html/footer.php");